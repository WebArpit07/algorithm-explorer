# Algorithm Explorer: An Analytical and Empirical Study of Algorithms, Growth of Functions and Computational Complexity

**University Course**: MSc (Information Technology)  
**Subject**: Discrete Mathematics (SC612)  
**Student Name**: Patel Arpit Dasharathbhai  
**Student Enrollment ID**: 202612120  
**Academic Reference**: Kenneth H. Rosen, *Discrete Mathematics and Its Applications*, 8th Edition, McGraw-Hill Education, Chapter 3.

---

## 1. Project Title & Scope

**Algorithm Explorer** is a comprehensive discrete mathematics study investigating algorithmic design, asymptotic growth analysis, and computational complexity. It bridges formal theoretical proofs with rigorous empirical benchmarking across four canonical algorithms:

1. **Linear Search** (Rosen §3.1, Algorithm 2) — $\mathcal{O}(n)$
2. **Binary Search** (Rosen §3.1, Algorithm 3) — $\mathcal{O}(\log n)$
3. **Bubble Sort** (Rosen §3.1, Algorithm 4, Classical Fixed-Pass Formulation) — $\Theta(n^2)$
4. **Insertion Sort** (Rosen §3.1, Algorithm 5, Adaptive Incremental Formulation) — Best $\mathcal{O}(n)$, Worst $\mathcal{O}(n^2)$

---

## 2. The Three Mandatory University Deliverables

In strict compliance with the faculty's handwritten assignment specifications, this submission directory provides the three required formats:

| Format | Deliverable Filename | Description | Status |
|---|---|---|---|
| **1. PDF** | [`Algorithm_Explorer_Report.pdf`](./Algorithm_Explorer_Report.pdf) | Complete 47-page master academic monograph containing all theoretical proofs, algorithm listings, execution outputs, and 9 vector figures. | **Ready for Review** (518 KB) |
| **2. LaTeX** | [`Algorithm_Explorer_Report.tex`](./Algorithm_Explorer_Report.tex) | Monolithic, self-contained LaTeX source code matching the submitted PDF, typeset using Kenneth H. Rosen as the sole academic reference. | **Fully Standalone** (82.7 KB) |
| **3. Notebook** | [`algorithm_explorer.ipynb`](./algorithm_explorer.ipynb) | Executed Jupyter Research Notebook (44 cells: 18 code, 26 markdown) containing all preserved execution outputs and telemetry tables. | **Pre-Executed & Verified** (3.5 MB) |

---

## 3. The Four Core Discrete Mathematics Topics Covered

As instructed by the faculty assignment prompt, this work thoroughly investigates:

1. **What is an Algorithm?**
   * Formal discrete mathematical definition (Rosen §3.1).
   * The seven essential characteristics: *Input, Output, Definiteness, Correctness, Finiteness, Effectiveness, Generality*.
   * Comparative evaluation of four representation paradigms: Natural Language, Pseudocode, Flowcharts, and Python Implementations.
2. **Types of Algorithms**
   * Classification by problem domain: Searching, Sorting, and Optimization.
   * Classification by algorithmic design paradigm: Brute Force, Divide-and-Conquer, Greedy, and Dynamic Programming.
   * Detailed analysis of the four core algorithms.
3. **The Growth of Functions**
   * Mathematical motivation and the dominant role of input size $n$ as $n \to \infty$.
   * The canonical hierarchy of growth rates:
     $$1 \prec \log_2 n \prec n \prec n\log_2 n \prec n^2 \prec 2^n \prec n!$$
   * Exact numerical evaluations across scales $n = 1$ to $n = 1024$ without labeling finite factorial quantities as infinite.
4. **Complexity of Algorithms**
   * Formal asymptotic notations: Big-$\mathcal{O}$ (upper bound), Big-$\Omega$ (lower bound), and Big-$\Theta$ (tight bound).
   * Explicit derivation of witness pairs $(C, k)$ for polynomial functions.
   * Case analysis: Best-case, Average-case (under uniform distribution), and Worst-case scenarios.
   * The **Inversion Equivalence Theorem** proving that Bubble Sort Swaps $\equiv$ Insertion Sort Right Shifts $\equiv I(A)$.

---

## 4. Experimental Figures and Datasets

This package includes all 9 publication-quality figures generated from empirical benchmarking over $k = 30$ independent replications per configuration:

* `figures/figure1_common_growth_functions.pdf` — Common polynomial and sub-polynomial growth curves ($n \le 50$).
* `figures/figure2_growth_hierarchy_log_scale.pdf` — Full growth hierarchy on semi-logarithmic vertical axis ($n \le 20$).
* `figures/figure3_search_operation_counts.pdf` — Linear Search vs. Binary Search operation counts across scenarios.
* `figures/figure4_search_execution_times.pdf` — Searching wall-clock execution durations in microseconds.
* `figures/figure5_sorting_operation_counts.pdf` — Sorting element comparisons and data movement operations.
* `figures/figure6_sorting_execution_times.pdf` — Sorting execution durations on random input permutations.
* `figures/figure7_insertion_sort_arrangements.pdf` — Adaptive behaviour of Insertion Sort across input topologies.
* `figures/figure8_bubble_sort_arrangements.pdf` — Comparison invariance in textbook Bubble Sort ($n(n-1)/2$).
* `figures/figure9_theoretical_vs_experimental.pdf` — Exact theoretical closed-form bounds plotted against empirical measurements ($R^2 > 0.999$, 0.00% discrepancy).

All supporting datasets are preserved in:
* `data/raw/` — Granular execution trial measurements.
* `data/processed/` — Aggregated statistical summaries (median, mean, standard deviation).

---

## 5. How to Open and Execute the Jupyter Notebook

The included notebook `algorithm_explorer.ipynb` has been fully executed with all outputs, DataFrames, and visualizations preserved. If you wish to re-run the cells locally:

1. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```
2. **Launch Jupyter Lab or Notebook**:
   ```bash
   jupyter notebook algorithm_explorer.ipynb
   ```
3. **Run All Cells**:
   Select **Kernel** $\to$ **Restart & Run All**.
   *Note: All necessary module files (`src/algorithms`, `src/benchmarking`, `src/visualization`) and data directories (`data/`) are provided in this submission folder, ensuring relative import paths resolve correctly.*

---

## 6. How to Compile the LaTeX Report

The LaTeX report [`Algorithm_Explorer_Report.tex`](./Algorithm_Explorer_Report.tex) is 100% standalone and uses standard TeX Live packages.

### Method A: Upload to Overleaf (1-Click, No Local Install Needed)
1. Open [Overleaf](https://www.overleaf.com/).
2. Create a new project and upload `Algorithm_Explorer_Report.tex` along with the `figures/` folder.
3. Select the compiler (`pdflatex`) and click **Recompile**.

### Method B: Local Command Line
If MiKTeX or TeX Live is installed:
```bash
pdflatex -interaction=nonstopmode Algorithm_Explorer_Report.tex
pdflatex -interaction=nonstopmode Algorithm_Explorer_Report.tex
```

---

## 7. Interactive Algorithm Explorer Web Dashboard (Optional Enhancement)

As an optional enhancement to the discrete mathematics assignment, an interactive web dashboard was created with zero external framework dependencies:

* **Local Execution**:
  To explore the visualizers and interactive labs locally:
  ```bash
  python -m http.server 8000
  ```
  Open `http://localhost:8000/dashboard/index.html` in your web browser.
* **Live Production Website**:
  The dashboard has been deployed to Cloudflare Edge:
  * **Verified Live Endpoint**: [https://algorithm-explorer.glitchhunter69.workers.dev/](https://algorithm-explorer.glitchhunter69.workers.dev/)
  * *Note on `algorithm-explorer.pages.dev`*: The custom Pages subdomain `https://algorithm-explorer.pages.dev` was planned during deployment, but the active, verified production endpoint published and linked across the monograph cover page and Chapter 8 is the Cloudflare Worker domain `https://algorithm-explorer.glitchhunter69.workers.dev/`.
* **Features Included**:
  * Linear and Binary Search step-by-step visualizers.
  * Bubble Sort and Insertion Sort vertical animated bar charts.
  * Interactive logarithmic growth curve explorer.
  * Head-to-head empirical comparison laboratories.

---

## 8. University Submission Checklist Summary

- [x] **Deliverable 1 (PDF)**: `Algorithm_Explorer_Report.pdf` (Verified, 47 pages, 518 KB)
- [x] **Deliverable 2 (LaTeX)**: `Algorithm_Explorer_Report.tex` (Verified, Standalone, 82.7 KB)
- [x] **Deliverable 3 (Jupyter Notebook)**: `algorithm_explorer.ipynb` (Verified, 44 cells with outputs, 3.5 MB)
- [x] **Figures**: Complete set of 9 PDF and PNG figures in `figures/`
- [x] **Modular Source Code**: `src/algorithms/`, `src/benchmarking/`, `src/visualization/`
- [x] **Microbenchmark Telemetry**: `data/raw/` and `data/processed/`
- [x] **Environment Specification**: `requirements.txt`
- [x] **Sole Academic Reference**: Kenneth H. Rosen, 8th Edition, Chapter 3
